MADONNA NASSER PORTFOLIO
========================
Files:
- index.html: homepage
- style.css: site styling
- technical-training.html
- food-exports.html
- educational.html
- accounting.html
- mental-health.html
- skincare.html

HOW TO PUBLISH ON GITHUB PAGES
1. Upload all HTML files and style.css to the same repository root.
2. Keep the homepage named index.html.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.

HOW TO ADD YOUR PHOTO / PROJECT IMAGES
This starter uses visible placeholders and does not pretend to contain your real work.
To add images through GitHub:
1. Create a folder named assets in the repository.
2. Upload your photo as madonna.jpg and project images into assets.
3. In index.html, replace the portrait placeholder block with:
   <img src="assets/madonna.jpg" alt="Madonna Nasser" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">
4. For each gallery placeholder, replace its contents with:
   <img src="assets/your-image.jpg" alt="Description of your work">
5. Upload the actual images using the same filenames you used in the HTML.

RESULTS NOTE
Mr. Math: reported EGP 8,000 campaign revenue and EGP 1,400 ad spend.
Mettamena: reported 80 bookings in the first month, session prices EGP 450–1,500, some three-session packages.
Verify with records before presenting these as audited or collected revenue. Bookings are not the same as revenue.
